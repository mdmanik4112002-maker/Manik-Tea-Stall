# My Inventory — Android starter project

This is the first-step native Android starter for the personal, offline-first inventory app.

## Included
- Kotlin + Jetpack Compose UI scaffold
- Modern Green Material 3 theme
- Room / SQLite product database
- Product entity and DAO
- Dashboard with product count, stock value and low-stock count
- Add product dialog and product list
- Camera permission and ML Kit barcode-scanning dependency prepared

## Not yet implemented
- Live camera barcode scanner UI and runtime permission flow
- Purchases, sales, stock movement ledger, suppliers and expenses
- Google Drive backup / restore and account authorization
- Export/import, reporting, database migration tests
- Release signing and APK build

## Open
Open this folder in Android Studio (Hedgehog or newer), allow Gradle sync, then run the `app` configuration on an Android device or emulator.

The project is a source-code starter, not a verified installable APK. Build and test it in Android Studio before using it with real business data.
