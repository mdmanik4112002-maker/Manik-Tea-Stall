package com.manik.myinventory.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY name COLLATE NOCASE ASC")
    fun observeProducts(): Flow<List<Product>>

    @Query("SELECT COUNT(*) FROM products")
    fun observeProductCount(): Flow<Int>

    @Query("SELECT COALESCE(SUM(quantity * purchasePrice), 0) FROM products")
    fun observeStockValue(): Flow<Double>

    @Query("SELECT COUNT(*) FROM products WHERE quantity <= minimumStock")
    fun observeLowStockCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(product: Product)

    @Query("DELETE FROM products WHERE id = :productId")
    suspend fun deleteById(productId: Long)
}
