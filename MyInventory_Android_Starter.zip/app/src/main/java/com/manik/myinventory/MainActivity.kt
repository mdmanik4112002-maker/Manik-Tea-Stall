package com.manik.myinventory

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import com.manik.myinventory.data.InventoryDatabase
import com.manik.myinventory.ui.InventoryApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val database = InventoryDatabase.getInstance(applicationContext)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(
                primary = Color(0xFF16834B),
                secondary = Color(0xFF2E9D67),
                background = Color(0xFFF5F8F5),
                surface = Color.White
            )) {
                InventoryApp(database.productDao())
            }
        }
    }
}
