package com.manik.myinventory.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val sku: String = "",
    val barcode: String = "",
    val category: String = "",
    val unit: String = "পিস",
    val purchasePrice: Double = 0.0,
    val salePrice: Double = 0.0,
    val quantity: Double = 0.0,
    val minimumStock: Double = 0.0,
    val updatedAt: Long = System.currentTimeMillis()
)
