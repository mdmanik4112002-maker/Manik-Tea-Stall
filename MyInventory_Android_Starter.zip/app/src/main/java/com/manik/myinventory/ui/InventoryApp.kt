package com.manik.myinventory.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.manik.myinventory.data.Product
import com.manik.myinventory.data.ProductDao
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

@Composable
fun InventoryApp(dao: ProductDao) {
    val products by dao.observeProducts().collectAsState(initial = emptyList())
    val productCount by dao.observeProductCount().collectAsState(initial = 0)
    val stockValue by dao.observeStockValue().collectAsState(initial = 0.0)
    val lowStock by dao.observeLowStockCount().collectAsState(initial = 0)
    var showAdd by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(title = {
                Column {
                    Text("My Inventory")
                    Text("আপনার ব্যবসার স্টক ব্যবস্থাপনা", style = MaterialTheme.typography.labelSmall)
                }
            })
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }, containerColor = MaterialTheme.colorScheme.primary) {
                Text("+", color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.headlineMedium)
            }
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 }, icon = { Text("⌂") }, label = { Text("হোম") })
                NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 }, icon = { Text("▣") }, label = { Text("পণ্য") })
                NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2 }, icon = { Text("☷") }, label = { Text("রিপোর্ট") })
                NavigationBarItem(selected = selectedTab == 3, onClick = { selectedTab = 3 }, icon = { Text("⚙") }, label = { Text("সেটিংস") })
            }
        }
    ) { padding ->
        if (selectedTab == 0) {
            Dashboard(
                modifier = Modifier.padding(padding),
                productCount = productCount,
                stockValue = stockValue,
                lowStock = lowStock,
                products = products
            )
        } else if (selectedTab == 1) {
            ProductList(Modifier.padding(padding), products)
        } else {
            Box(Modifier.fillMaxSize().padding(padding).padding(24.dp)) {
                Text(
                    when (selectedTab) {
                        2 -> "রিপোর্ট মডিউল পরবর্তী ধাপে যুক্ত হবে"
                        else -> "সেটিংস ও Google Drive ব্যাকআপ পরবর্তী ধাপে যুক্ত হবে"
                    }
                )
            }
        }
    }

    if (showAdd) {
        AddProductDialog(
            onDismiss = { showAdd = false },
            onSave = { product ->
                // Database writes are launched in the composable scope below.
            },
            dao = dao
        )
    }
}

@Composable
private fun Dashboard(
    modifier: Modifier,
    productCount: Int,
    stockValue: Double,
    lowStock: Int,
    products: List<Product>
) {
    val money = remember { NumberFormat.getNumberInstance(Locale("bn", "BD")) }
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("ড্যাশবোর্ড", style = MaterialTheme.typography.headlineSmall)
            Text("আজকের ব্যবসার সারসংক্ষেপ", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SummaryCard("মোট পণ্য", money.format(productCount), Modifier.weight(1f))
                SummaryCard("কম স্টক", money.format(lowStock), Modifier.weight(1f))
            }
        }
        item {
            SummaryCard("মোট স্টক ভ্যালু", "৳ ${money.format(stockValue)}", Modifier.fillMaxWidth())
        }
        item { Text("সাম্প্রতিক পণ্য", style = MaterialTheme.typography.titleMedium) }
        if (products.isEmpty()) {
            item {
                Card {
                    Column(Modifier.fillMaxWidth().padding(20.dp)) {
                        Text("এখনো কোনো পণ্য যোগ করা হয়নি")
                        Text("নিচের + বাটনে চাপ দিয়ে প্রথম পণ্য যোগ করুন।", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        } else {
            items(products.take(5), key = { it.id }) { product ->
                ProductRow(product)
            }
        }
    }
}

@Composable
private fun SummaryCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun ProductList(modifier: Modifier, products: List<Product>) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("পণ্যের তালিকা", style = MaterialTheme.typography.headlineSmall) }
        if (products.isEmpty()) item { Text("কোনো পণ্য পাওয়া যায়নি।") }
        items(products, key = { it.id }) { ProductRow(it) }
    }
}

@Composable
private fun ProductRow(product: Product) {
    Card {
        Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(product.name, style = MaterialTheme.typography.titleMedium)
                Text("${product.category.ifBlank { "ক্যাটাগরি নেই" }} • ${product.barcode.ifBlank { "বারকোড নেই" }}",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Column {
                Text("স্টক: ${product.quantity} ${product.unit}")
                Text("৳ ${product.salePrice}", color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
private fun AddProductDialog(onDismiss: () -> Unit, onSave: (Product) -> Unit, dao: ProductDao) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var barcode by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("পিস") }
    var purchase by remember { mutableStateOf("") }
    var sale by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("") }
    var minimum by remember { mutableStateOf("0") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("নতুন পণ্য যোগ করুন") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("পণ্যের নাম *") }, singleLine = true)
                OutlinedTextField(barcode, { barcode = it }, label = { Text("বারকোড") }, singleLine = true)
                OutlinedTextField(category, { category = it }, label = { Text("ক্যাটাগরি") }, singleLine = true)
                OutlinedTextField(unit, { unit = it }, label = { Text("একক (পিস/কেজি/লিটার)") }, singleLine = true)
                OutlinedTextField(purchase, { purchase = it }, label = { Text("ক্রয়মূল্য (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(sale, { sale = it }, label = { Text("বিক্রয়মূল্য (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(quantity, { quantity = it }, label = { Text("প্রাথমিক স্টক") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(minimum, { minimum = it }, label = { Text("সর্বনিম্ন স্টক সতর্কতা") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank(),
                onClick = {
                    val item = Product(
                        name = name.trim(),
                        barcode = barcode.trim(),
                        category = category.trim(),
                        unit = unit.trim().ifBlank { "পিস" },
                        purchasePrice = purchase.toDoubleOrNull() ?: 0.0,
                        salePrice = sale.toDoubleOrNull() ?: 0.0,
                        quantity = quantity.toDoubleOrNull() ?: 0.0,
                        minimumStock = minimum.toDoubleOrNull() ?: 0.0
                    )
                    scope.launch { dao.upsert(item) }
                    onSave(item)
                    onDismiss()
                }
            ) { Text("সংরক্ষণ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}
